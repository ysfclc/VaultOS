# Build correction — run 5

Run: https://github.com/ysfclc/VaultOS/actions/runs/41080734760

The previous workflow correction succeeded: Android SDK setup, SDK package installation, and Gradle setup all passed. The build reached `:app:compileDebugKotlin` and reported these source errors:

1. `VaultKeyboardService.kt`: `currentInputMethodSubtype` was accessed on `InputMethodService`, where it is not exposed. The service now queries `InputMethodManager.currentInputMethodSubtype`, with the device locale as fallback.
2. `VaultDocumentsProvider.kt`: `MatrixCursor.RowBuilder.add(index, value)` selected a nonexistent overload. It now uses the documented column-name overload.
3. `VaultBackupManager.kt`: restore called suspend Room/repository methods from a regular function. `restore` is now `suspend`; its existing UI call is already inside an IO coroutine context.

Validation status: source-level fixes and package/static checks are included in this update. A fresh CI run must still confirm compiler, tests, lint, and APK assembly. Device testing remains pending.
