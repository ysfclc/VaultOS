# VaultOS update — lint fixes after Run #6

## Findings

The Android SDK and Kotlin compilation now pass. The next build stopped at Android Lint with four errors:

1. `InputMethodService.switchToNextInputMethod()` requires API 28 while VaultOS supports API 26.
2. `android:windowLightNavigationBar` requires API 27 but was declared in the base `values` resources.
3. Compose `produceState` in the device file browser triggered `ProduceStateDoesNotAssignValue` despite the producer assignment.
4. The installed-app catalogue requires package visibility across installed apps; lint flags `QUERY_ALL_PACKAGES` without an explicit rationale.

## Changes

- Use `switchToNextInputMethod(false)` on API 28+, and the system input-method picker on API 26–27.
- Move the navigation-bar appearance attribute into `res/values-v27/styles.xml`.
- Replace the file-browser `produceState` with `remember` state updated by `LaunchedEffect` and an IO dispatcher.
- Document and explicitly suppress the package-visibility lint warning for `QUERY_ALL_PACKAGES`, which supports the core installed-app catalogue/APK archiving feature. This permission remains subject to Google Play policy if the app is ever published there.

## Verification status

Static source and XML checks are performed on this package. A full Android Gradle build must be confirmed by the next GitHub Actions run.
