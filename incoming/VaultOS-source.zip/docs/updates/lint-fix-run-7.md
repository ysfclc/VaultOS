# Android CI correction — run 7

Run 7 did not validate the newer local package: the repository import marker showed that the ZIP already stored at `incoming/VaultOS-source.zip` had been imported previously, so the workflow correctly skipped re-extraction and compiled the older keyboard implementation.

This package deliberately changes the keyboard toolbar's Switch action to call Android's system input-method picker on every supported API level. This removes the API-28-only `switchToNextInputMethod` call entirely while preserving the user-visible ability to switch between VaultOS and Gboard. The other run-6 lint corrections remain in place: API-qualified navigation-bar styling, Compose folder state loading via `LaunchedEffect`, and the documented package-visibility permission suppression.

Upload this newly generated ZIP to `incoming/VaultOS-source.zip`, replacing the existing file. Its SHA-256 differs from the repository's previous import marker, so the existing workflow will extract and commit it before running tests, lint, and APK assembly.
