# Run 8: prevent stale source ZIP imports

The previous manual run did not import a new archive: GitHub reported `This exact source ZIP was already extracted.` The repository still had the old API-28-only `switchToNextInputMethod(false)` call. The corrected source ZIP was present in the local handoff package but was not the ZIP stored at `incoming/VaultOS-source.zip` in the repository.

The workflow now always inspects and extracts the uploaded archive instead of trusting the old SHA marker as proof that the checkout matches it. It rejects the known stale keyboard call before Gradle starts, then verifies all four previously reported lint fixes in the checked-out source.

The keyboard's Switch action uses Android's system input-method picker on API 26+, while the saved-text paste path remains chunked into 8,000-character commits to avoid oversized Binder transactions.
