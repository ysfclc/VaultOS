# VaultOS Phase 2 — 0.2.0

## Delivered

- Recycle Bin for managed archive files with restore, collision-safe restore paths, and permanent deletion.
- Room schema v1→v2 migration for recycle-bin state; normal library, search, count and archived-size views ignore trashed entries.
- Backup manifest support for trashed records and their original archive paths.
- Multi-select in the device/vault file browser with batch copy, move, archive, ZIP creation and delete/Recycle Bin actions.
- ZIP create/extract with traversal validation, a 20,000-entry limit and a 2 GiB expanded-data ceiling.
- Progress and Cancel UI for copy, move, archive, extraction and delete.
- Downsampled image thumbnails in list rows and larger image previews in item details.

## Safety details

- Copy, archive and ZIP/extraction writes use temporary outputs and clean them up on failure/cancellation.
- Same-filesystem moves use rename. Cross-filesystem moves complete a full copy before source deletion.
- Extraction canonicalizes every output path and refuses paths outside its temporary extraction root.

## Verification

- :app:testDebugUnitTest passed.
- :app:lintDebug passed.
- :app:assembleDebug passed.
- Manual testing on a Redmi Note 12 Pro 5G is still pending; see docs/DEVICE-TEST-PLAN.md.
