# VaultOS 0.3.0 — application and backup management

## Changes

- Bumped Android versionCode to 3 / versionName to 0.3.0; no Room schema migration is required.
- Kept the exact 0.2.0 signing certificate and re-encrypted its private key for persistent local sideload builds. Debug and release variants share the certificate.
- Added signed release APK build and key-management documentation.
- Moved installed-app catalogue enumeration, package metadata reads and archived APK metadata parsing off the UI thread.
- Added installed-versus-archived package version comparison and visible base/split component counts. APK export archives base and split files individually and explains that all components must be retained.
- Removed full private-vault recursive reconciliation from every shared-storage scan; retained explicit vault-only sync after vault file operations.
- Debounced MediaStore observer notifications, rate-limited foreground scan requests, shortened each initial scan worker batch to 90 seconds, checkpointed every 10 directories, and yielded/reported progress every 50 files.
- Ensured scan cancellation propagates instead of being swallowed by a per-file `runCatching`.
- Added a bounded thumbnail LRU cache to avoid repeated expensive preview decoding during scrolling.

## Verification

Pending clean test, lint, debug APK and signed release APK build in the delivery environment. Physical Redmi validation is still required.
