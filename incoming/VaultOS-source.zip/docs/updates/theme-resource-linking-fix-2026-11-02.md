# Android resource-linking fix — 2026-11-02

## Source and failure

- Repository: ysfclc/VaultOS
- Source archive: incoming/VaultOS-source.zip
- Source archive SHA-256: 27ffc09c540162c0e6f8c01fa75caa2011855b1c4f1b167a6164b05a647a33ef
- Reported Actions failure: run 10, task :app:processDebugResources
- AAPT error: resource style/Theme (aka com.vaultos.app:style/Theme) not found

## Root cause

The base Theme.VaultOS style declared android:style/Theme.Material.Light.NoActionBar as its parent. The values-v27 resource variant redeclared Theme.VaultOS without a parent, causing Android to infer @style/Theme, which does not exist. The qualified style also omitted the base style's visual attributes.

## Changes

- Added the same explicit parent to values-v27/Theme.VaultOS.
- Copied all base theme items into the qualified style and retained android:windowLightNavigationBar=false.
- Added XML-based pre-import and post-import workflow validation for the parent, all base theme items, and the API-27 navigation override.
- Protected both .github/workflows/android-build.yml and the root android-build.yml mirror from being overwritten by an older source ZIP.
- Updated README, project status, and task ledger.

## Verification

- Source and qualified resource XML parse successfully.
- Workflow YAML parses successfully.
- Theme parent and item parity checks pass.
- Clean Gradle command gradle --no-daemon clean testDebugUnitTest lintDebug assembleDebug completed successfully with JDK 17, Gradle 8.9, Android SDK Platform 35, and Build Tools 35.0.0.
- Unit tests: 4 passed, 0 failed; lint passed; debug APK assembled (17 MB).
- Debug APK SHA-256: fdd641a3d4bd2ed9711c22f418c0342f54468313325c4eccb66f6c6730640042.
- GitHub-hosted Actions confirmation and physical-device testing remain pending.
